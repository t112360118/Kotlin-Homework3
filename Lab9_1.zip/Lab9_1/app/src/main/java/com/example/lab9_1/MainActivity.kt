package com.example.lab9_1

import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private var progressRabbit = 0
    private var progressTurtle = 0

    private lateinit var btnStart: Button
    private lateinit var sbRabbit: SeekBar
    private lateinit var sbTurtle: SeekBar

    // 建立 CoroutineScope（生命週期綁在 Activity）
    private val raceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        btnStart = findViewById(R.id.btnStart)
        sbRabbit = findViewById(R.id.sbRabbit)
        sbTurtle = findViewById(R.id.sbTurtle)

        btnStart.setOnClickListener {
            btnStart.isEnabled = false

            // 重置賽況
            progressRabbit = 0
            progressTurtle = 0
            sbRabbit.progress = 0
            sbTurtle.progress = 0

            // 同時啟動兩個選手
            runRabbit()
            runTurtle()
        }
    }

    /** 顯示 Toast */
    private fun showToast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    /** 使用 Coroutine 模擬兔子 */
    private fun runRabbit() {
        raceScope.launch {
            val sleepChance = arrayOf(true, true, false)

            while (progressRabbit < 100 && progressTurtle < 100) {

                delay(100) // 更新頻率

                if (sleepChance.random())
                    delay(300) // 偷懶

                progressRabbit += 3

                // 更新 UI 需切換回主執行緒
                withContext(Dispatchers.Main) {
                    sbRabbit.progress = progressRabbit
                    if (progressRabbit >= 100 && progressTurtle < 100) {
                        showToast("兔子勝利")
                        btnStart.isEnabled = true
                    }
                }
            }
        }
    }

    /** 使用 Coroutine 模擬烏龜 */
    private fun runTurtle() {
        raceScope.launch {
            while (progressTurtle < 100 && progressRabbit < 100) {

                delay(100)
                progressTurtle += 1

                withContext(Dispatchers.Main) {
                    sbTurtle.progress = progressTurtle
                    if (progressTurtle >= 100 && progressRabbit < 100) {
                        showToast("烏龜勝利")
                        btnStart.isEnabled = true
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        raceScope.cancel() // 避免 coroutine 外洩
    }
}
